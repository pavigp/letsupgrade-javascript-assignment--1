let num = prompt("Enter a number:");
console.log(num);

function odd(numb){
    let result = (numb%2==0) ? 'It is even' : 'It is odd'
return result;
}

let res = odd(num);
console.log(res);

