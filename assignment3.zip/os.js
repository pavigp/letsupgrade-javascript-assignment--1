let arr= prompt("Enter your os name and version");
console.log(arr);
let txtv = arr.split(" ");
console.log ('The entered OS and version is: ' +txtv);
